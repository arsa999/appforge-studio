# AppForge Studio

An English-language starter project for a browser-based Android app builder. It includes a responsive static web UI with working local demo interactions for projects, a code editor, visual component schema, website-to-app configuration, native component schema, templates, and build history.

## Important scope note

This is a **front-end MVP prototype**, not yet a production hosted service. It does not generate a real APK in the browser. The Build button records a clearly marked demo-only request. A real APK requires a backend API and a secured Android SDK/Gradle build worker. Authentication is also a UI placeholder; local demo data is stored in the browser's localStorage.

## Run locally

You can open `web/index.html` directly in a modern browser, or run a static server:

```bash
cd web
python -m http.server 8080
```

Then visit `http://localhost:8080`.

## Deploy the front end for free

1. Push this folder to a Git repository.
2. Create a static site project with a provider such as Cloudflare Pages.
3. Set the project root to `web`.
4. No build command is required for this static HTML version; set the output directory to `.` if the provider requires one.
5. Deploy and test on desktop and mobile.

The exact free-tier limits and provider configuration can change. Do not treat free hosting as a guarantee of free Android build compute.

## Project layout

- `web/index.html` — responsive UI and browser-only demo functionality
- `api/` — minimal backend API scaffold
- `android/webview-template/` — starter Kotlin WebView Android template
- `docs/BUILD_WORKER.md` — recommended real APK worker architecture

## Recommended next production steps

1. Replace localStorage project persistence with a backend API and database.
2. Add authentication and strict per-user authorization.
3. Store project assets and generated APKs in private object storage.
4. Add a queue and isolated build workers with timeouts and resource limits.
5. Validate project schemas, paths, package IDs, URLs, and uploaded files.
6. Generate a WebView Android project from a trusted template and run Gradle in an isolated environment.
7. Add Kotlin/Jetpack Compose code generation for the supported native component schema.
8. Verify artifacts and use secure release-signing key management.
9. Add automated tests, logging, monitoring, backups, and abuse controls.

## Security notes

- Never put server credentials or Android release signing keys in the browser bundle or Git repository.
- Never run untrusted project code on the API host.
- Isolate each build, enforce quotas and timeouts, and do not expose the worker publicly without authenticated job dispatch.
- Restrict WebView navigation and JavaScript bridges; only grant Android permissions when needed.
- Release signing keys must be encrypted and access-controlled.


## Real APK/AAB build backend (new)

The `api/`, `worker/`, `android/webview-template/`, and `docker-compose.yml` now include a queued Android SDK/Gradle pipeline for building WebView APK/AAB artifacts from a public HTTPS URL. See [`docs/BUILD_WORKER.md`](docs/BUILD_WORKER.md) for setup and API examples. This requires a Linux Docker host; the backend has not been deployed or executed in this environment. The browser UI still needs wiring to the authenticated API and artifact downloads before end-to-end use.
